package com.example.nightshiftburger

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.AdError

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var interstitial: InterstitialAd? = null
    private var shownThisLaunch = false
    private val testAdUnit = "ca-app-pub-3940256099942544/1033173712"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        )
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(PlayBridge(), "AndroidAds")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                installPlayHook()
            }
        }
        MobileAds.initialize(this) { loadAd() }
        webView.loadUrl("https://rosebud.ai/d/night-shift-burger-from-hell")
    }

    private fun loadAd() {
        InterstitialAd.load(this, testAdUnit, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null }
            })
    }

    private inner class PlayBridge {
        @JavascriptInterface fun onPlayClicked() {
            runOnUiThread {
                if (shownThisLaunch) { continueGame(); return@runOnUiThread }
                val ad = interstitial
                if (ad == null) { continueGame(); return@runOnUiThread }
                shownThisLaunch = true
                interstitial = null
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        continueGame()
                    }
                    override fun onAdFailedToShowFullScreenContent(error: AdError) {
                        continueGame()
                    }
                }
                ad.show(this@MainActivity)
            }
        }
    }

    private fun continueGame() {
        webView.evaluateJavascript(
            "window.__nightShiftContinuePlay && window.__nightShiftContinuePlay();", null)
    }

    private fun installPlayHook() {
        val js = """
          (function() {
            if (window.__nightShiftHookInstalled) return;
            window.__nightShiftHookInstalled = true;
            window.__nightShiftContinuePlay = function() {
              window.__nightShiftBypass = true;
              if (window.__nightShiftPlayEl) window.__nightShiftPlayEl.click();
            };
            document.addEventListener('click', function(e) {
              if (window.__nightShiftBypass) { window.__nightShiftBypass = false; return; }
              var el = e.target;
              while (el && el !== document) {
                var t = ((el.innerText || el.getAttribute('aria-label') || el.value || '') + '').trim().toLowerCase();
                if (t === 'play' || t === 'start' || t === 'gioca') {
                  window.__nightShiftPlayEl = el;
                  e.preventDefault();
                  e.stopImmediatePropagation();
                  if (window.AndroidAds) window.AndroidAds.onPlayClicked();
                  return;
                }
                el = el.parentElement;
              }
            }, true);
          })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
