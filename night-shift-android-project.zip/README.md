# Night Shift: Burger from Hell — Android wrapper

Opens the existing Rosebud game in an Android WebView and includes Google's **test** interstitial ad unit.

## Important
- This is a starter project, not a finished/published app.
- The PLAY interception is best-effort and is NOT guaranteed. It looks for HTML click targets labelled PLAY, START or GIOCA. It will not reliably detect a canvas-rendered button or a button inside a separate frame. Verify on a real Android device.
- The Google test ad IDs are not monetization IDs. Replace them with your own AdMob app/ad unit IDs before release.
- Configure Google UMP consent and privacy disclosures for applicable regions, including the EEA.
- A signed release AAB and Play Console setup are still required.
- Check Rosebud terms and Google Play policies before distributing a WebView wrapper.

## Build
Push this repository to GitHub. GitHub Actions builds a debug APK on push or when manually started from the Actions tab.
